import { domMax } from 'framer-motion';

export default domMax;
