export const navItems = [
  {
    name: "Home",
    link: "/",
  },
  {
    name: "About us",
    link: "/aboutus/aboutus",
  },
  {
    name: "Jobs",
    link: "/jobs",
  },
  {
    name: "Testimonials",
    link: "/testimonial/testimonials",
  },
  {
    name: "FAQ",
    link: "/faqs",
  },
  {
    name: "Blog",
    link: "/blog",
  },
  {
    name: "Contact us",
    link: "/contact",
  },
];